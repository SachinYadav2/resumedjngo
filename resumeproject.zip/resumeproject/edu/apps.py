from django.apps import AppConfig


class EduConfig(AppConfig):
    name = 'edu'
